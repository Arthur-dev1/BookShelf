# BookShelf

BookShelf ir personīgā grāmatu bibliotēka kas izveidota izmantojot Laravel 13, Blade, SQLite un Laravel Breeze autentifikāciju.

## Prasības!!

- PHP 8.3 ar nepieciešamajiem Laravel paplašinājumiem
- Composer
- Node.js un npm (nepieciešami tikai tad, ja tiek atkārtoti ģenerēti frontend) resursi

## Instalēsana 

1. Izpakojiet projekta ZIP arhīvu "BookShelf".
2. Atveriet termināli izpakotā projekta direktorijā (search bar -> cmd -> Enter).
3. Instalējiet PHP atkarības, ja `vendor` direktorija nav iekļauta!:

   `composer install`

4. Nokopējiet `.env.example` uz `.env`.
5. Ģenerējiet lietotnes atslēgu:

   `php artisan key:generate`

6. Pārliecinieties, ka `.env` failā ir konfigurēta SQLite:

   `DB_CONNECTION=sqlite`


7. Ja frontend resursi vēl nav ģenerēti:

   `npm install`

   `npm run build`

8. Palaidiet lietotni:

    `php artisan serve`

9. Atveriet http://127.0.0.1:8000 savā pārlūkprogrammā un reģistrējiet kontu!

## Datubāze

Projektā ir iekļautas datubāzes migrācijas un seeders!

## Funkcionalitāte:

- Lietotāju reģistrācija un autentifikācija
- Autora un grāmatas modeļi ar one-to-many saistību
- Pilnas CRUD operācijas grāmatām
- Datubāzes sēšanas skripti ar paraugu ierakstiem
- Grāmatu meklēšana, izmantojot AJAX
- Ievades validācija servera pusē
- Responsīva lietotāja saskarne, kas veidota ar Blade


## Svarīgi!!! :  šīs komandas paredz, ka PHP, Composer un Node.js ir instalēti un pieejami jūsu terminālī


## =======================================================================================================================



## LINUX lietotājiem:

Lietotni var darbināt arī Linux vidē! Izpildiet tās pašas iestatīšanas darbības, kas aprakstītas iepriekš, ņemot vērā šādas atšķirības:

**1. Instalējiet nepieciešamās atkarības**

Pārliecinieties, vai ir instalēti PHP, Composer, SQLite, Node.js un npm. 
Iespējams būs nepieciešami arī Laravel darbībai vajadzīgie PHP paplašinājumi.

Debian/Ubuntu sistēmās biežākās atkarības var instalēt ar šādu komandu:

```bash
sudo apt update
sudo apt install php-cli php-sqlite3 php-mbstring php-xml php-curl php-zip unzip sqlite3 composer nodejs npm
```

**2. Atveriet projekta direktoriju**

Izpakojiet ZIP arhīvu un pārejiet uz projekta mapi:

```bash
cd /path/to/bookshelf
```

Aizstājiet `/path/to/bookshelf` ar FAKTISKO ceļu uz direktoriju kurā izpakojāt projektu!!!

**3. Izveidojiet vides konfigurācijas failu**

Izmantojiet Linux komandu, lai nokopētu vides konfigurācijas paraugfailu:

```bash
cp .env.example .env
```

Ģenerējiet lietotnes atslēgu:

```bash
php artisan key:generate
```

**4. Konfigurējiet SQLite**

Pārliecinieties, vai `.env` fails ir konfigurēts SQLite izmantošanai. Ja datubāzes fails vēl nepastāv, izveidojiet to:

```bash
touch database/database.sqlite
```

Pārliecinieties, vai lietotājam, kurš darbina lietotni, IR atļauja piekļūt datubāzes failam un rakstīt `database` direktorijā.

Izpildiet migrācijas un seed skriptus:

```bash
php artisan migrate --seed
```

**5. Instalējiet atkarības un ja nepieciešams sagatavojiet saskarnes resursus**

TIKAI, JA ZIP arhīvā nav iekļauta `vendor` direktorija:

```bash
composer install
```

Ja trūkst saskarnes atkarību vai kompilēto resursu:

```bash
npm install
npm run build
```

**6. Palaidiet lietotni**

```bash
php artisan serve
```

Atveriet `http://127.0.0.1:8000` savā pārlūkprogrammā!

**Piezīme:** Ja ZIP arhīvā jau IR iekļauta SQLite datubāze (un tā IR!) ar sākotnējiem datiem (seed datiem), NEVEICIET migrācijas un seeder darbības.
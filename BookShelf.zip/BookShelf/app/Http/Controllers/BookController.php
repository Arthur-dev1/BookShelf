<?php

namespace App\Http\Controllers;

use App\Models\Author;
use App\Models\Book;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class BookController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->string('search')->toString();

        $books = Book::with('author')
            ->when($search, function ($query, $search) {
                $query->where(function ($query) use ($search) {
                    $query->where('title', 'like', "%{$search}%")
                        ->orWhere('genre', 'like', "%{$search}%")
                        ->orWhereHas('author', function ($query) use ($search) {
                            $query->where('name', 'like', "%{$search}%");
                        });
                });
            })
            ->latest()
            ->get();

        if ($request->ajax()) {
            return response()->json([
                'html' => view('books.partials.list', compact('books'))->render(),
                'count' => $books->count(),
            ]);
        }

        return view('books.index', compact('books', 'search'));
    }

    public function create()
    {
        $authors = Author::orderBy('name')->get();

        return view('books.create', compact('authors'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'author_id' => ['required', 'exists:authors,id'],
            'genre' => ['required', 'string', 'max:100'],
            'published_year' => [
                'required', 'integer', 'min:1000',
                'max:' . (date('Y') + 1),
            ],
            'description' => ['nullable', 'string', 'max:2000'],
        ]);

        Book::create($validated);

        return redirect()->route('books.index')
            ->with('success', 'Book added successfully.');
    }

    public function edit(Book $book)
    {
        $authors = Author::orderBy('name')->get();

        return view('books.edit', compact('book', 'authors'));
    }

    public function update(Request $request, Book $book)
    {
        $validated = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'author_id' => ['required', 'exists:authors,id'],
            'genre' => ['required', 'string', 'max:100'],
            'published_year' => [
                'required', 'integer', 'min:1000',
                'max:' . (date('Y') + 1),
            ],
            'description' => ['nullable', 'string', 'max:2000'],
        ]);

        $book->update($validated);

        return redirect()->route('books.index')
            ->with('success', 'Book updated successfully.');
    }

    public function destroy(Book $book)
    {
        $book->delete();

        return redirect()->route('books.index')
            ->with('success', 'Book deleted successfully.');
    }
}

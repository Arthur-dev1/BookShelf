<?php

namespace Database\Seeders;

use App\Models\Author;
use App\Models\Book;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call(AuthorSeeder::class);

        $authors = Author::all()->keyBy('name');

        $books = [
            [
                'author' => 'George Orwell',
                'title' => '1984',
                'genre' => 'Dystopian',
                'year' => 1949,
                'description' => 'A classic novel about surveillance and totalitarianism.',
            ],
            [
                'author' => 'George Orwell',
                'title' => 'Animal Farm',
                'genre' => 'Satire',
                'year' => 1945,
                'description' => 'A political allegory told through a farm rebellion.',
            ],
            [
                'author' => 'Jane Austen',
                'title' => 'Pride and Prejudice',
                'genre' => 'Romance',
                'year' => 1813,
                'description' => 'A novel about first impressions, relationships and class.',
            ],
            [
                'author' => 'J.R.R. Tolkien',
                'title' => 'The Hobbit',
                'genre' => 'Fantasy',
                'year' => 1937,
                'description' => 'Bilbo Baggins embarks on an unexpected adventure.',
            ],
            [
                'author' => 'Agatha Christie',
                'title' => 'Murder on the Orient Express',
                'genre' => 'Mystery',
                'year' => 1934,
                'description' => 'Hercule Poirot investigates a murder aboard a train.',
            ],
        ];

        foreach ($books as $book) {
            Book::firstOrCreate(
                ['title' => $book['title']],
                [
                    'author_id' => $authors[$book['author']]->id,
                    'genre' => $book['genre'],
                    'published_year' => $book['year'],
                    'description' => $book['description'],
                ]
            );
        }
    }
}

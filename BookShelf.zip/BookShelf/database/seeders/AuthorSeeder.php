<?php

namespace Database\Seeders;

use App\Models\Author;
use Illuminate\Database\Seeder;

class AuthorSeeder extends Seeder
{
    public function run(): void
    {
        $authors = [
            ['name' => 'George Orwell', 'email' => 'george@example.com'],
            ['name' => 'Jane Austen', 'email' => 'jane@example.com'],
            ['name' => 'J.R.R. Tolkien', 'email' => 'tolkien@example.com'],
            ['name' => 'Agatha Christie', 'email' => 'agatha@example.com'],
        ];

        foreach ($authors as $author) {
            Author::firstOrCreate(
                ['email' => $author['email']],
                $author
            );
        }
    }
}

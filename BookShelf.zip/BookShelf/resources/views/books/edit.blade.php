<x-app-layout>
    <div class="library-page form-page">
        <a href="{{ route('books.index') }}" class="back-link">
            &larr; Back to library
        </a>

        <div class="form-panel">
            <p class="eyebrow">UPDATE YOUR COLLECTION</p>
            <h1>Edit book</h1>
            <p class="page-subtitle">
                Update the details for {{ $book->title }}.
            </p>

            @include('books.partials.form')
        </div>
    </div>
</x-app-layout>

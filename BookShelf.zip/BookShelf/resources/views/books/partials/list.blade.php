@if ($books->isEmpty())
    <div class="empty-state">
        <h3>No books found</h3>
        <p>Try another search or add a new book to your library.</p>
    </div>
@else
    <div class="book-grid">
        @foreach ($books as $book)
            <article class="book-card">
                <div class="book-cover">
                    <span>{{ strtoupper(substr($book->title, 0, 1)) }}</span>
                </div>

                <div class="book-info">
                    <span class="book-genre">{{ $book->genre }}</span>
                    <h3>{{ $book->title }}</h3>
                    <p class="book-author">
                        By {{ $book->author->name }}
                    </p>
                    <p class="book-year">
                        Published {{ $book->published_year }}
                    </p>

                    @if ($book->description)
                        <p class="book-description">
                            {{ $book->description }}
                        </p>
                    @endif

                    <div class="book-actions">
                        <a href="{{ route('books.edit', $book) }}"
                           class="btn btn-secondary">Edit</a>

                        <form action="{{ route('books.destroy', $book) }}"
                              method="POST"
                              onsubmit="return confirm('Delete this book?')">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-danger" type="submit">
                                Delete
                            </button>
                        </form>
                    </div>
                </div>
            </article>
        @endforeach
    </div>
@endif

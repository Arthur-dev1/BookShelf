<form
    action="{{ $book ? route('books.update', $book) : route('books.store') }}"
    method="POST"
    class="book-form"
>
    @csrf

    @if ($book)
        @method('PUT')
    @endif

    <div class="form-field">
        <label for="title">Book title</label>
        <input id="title" name="title" type="text"
               value="{{ old('title', $book?->title) }}"
               maxlength="255" required>
        @error('title') <p class="field-error">{{ $message }}</p> @enderror
    </div>

    <div class="form-field">
        <label for="author_id">Author</label>
        <select id="author_id" name="author_id" required>
            <option value="">Choose an author</option>
            @foreach ($authors as $author)
                <option value="{{ $author->id }}"
                    @selected(old('author_id', $book?->author_id) == $author->id)>
                    {{ $author->name }}
                </option>
            @endforeach
        </select>
        @error('author_id') <p class="field-error">{{ $message }}</p> @enderror
    </div>

    <div class="form-row">
        <div class="form-field">
            <label for="genre">Genre</label>
            <input id="genre" name="genre" type="text"
                   value="{{ old('genre', $book?->genre) }}"
                   maxlength="100" required>
            @error('genre') <p class="field-error">{{ $message }}</p> @enderror
        </div>

        <div class="form-field">
            <label for="published_year">Publication year</label>
            <input id="published_year" name="published_year" type="number"
                   min="1000" max="{{ date('Y') + 1 }}"
                   value="{{ old('published_year', $book?->published_year) }}"
                   required>
            @error('published_year')
                <p class="field-error">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="form-field">
        <label for="description">Description (optional)</label>
        <textarea id="description" name="description"
                  rows="4" maxlength="2000">{{ old('description', $book?->description) }}</textarea>
        @error('description')
            <p class="field-error">{{ $message }}</p>
        @enderror
    </div>

    <div class="form-actions">
        <a href="{{ route('books.index') }}" class="btn btn-secondary">
            Cancel
        </a>
        <button type="submit" class="btn btn-primary">
            {{ $book ? 'Save changes' : 'Add book' }}
        </button>
    </div>
</form>

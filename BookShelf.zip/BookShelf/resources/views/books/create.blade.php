<x-app-layout>
    <div class="library-page form-page">
        <a href="{{ route('books.index') }}" class="back-link">
            &larr; Back to library
        </a>

        <div class="form-panel">
            <p class="eyebrow">GROW YOUR COLLECTION</p>
            <h1>Add a new book</h1>
            <p class="page-subtitle">Enter the details below.</p>

            @php($book = null)
            @include('books.partials.form')
        </div>
    </div>
</x-app-layout>

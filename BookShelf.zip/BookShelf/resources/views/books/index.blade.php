<x-app-layout>
    <div class="library-page">
        <header class="library-header">
            <div>
                <p class="eyebrow">YOUR PERSONAL COLLECTION</p>
                <h1>My BookShelf</h1>
                <p class="page-subtitle">
                    Keep track of the stories worth remembering.
                </p>
            </div>

            <a href="{{ route('books.create') }}" class="btn btn-primary">
                + Add a book
            </a>
        </header>

        @if (session('success'))
            <div class="success-message">{{ session('success') }}</div>
        @endif

        <section class="library-toolbar">
            <div>
                <h2>Your collection</h2>
                <p><span id="book-count">{{ $books->count() }}</span> books in your results</p>
            </div>

            <div class="search-box">
                <input
                    id="book-search"
                    type="search"
                    value="{{ $search }}"
                    placeholder="Search title, author or genre..."
                    autocomplete="off"
                    aria-label="Search books"
                >
                <span class="search-icon">⌕</span>
            </div>
        </section>

        <div id="book-results" aria-live="polite">
            @include('books.partials.list', ['books' => $books])
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const searchInput = document.getElementById('book-search');
            const results = document.getElementById('book-results');
            const count = document.getElementById('book-count');
            let controller;

            searchInput.addEventListener('input', async () => {
                if (controller) controller.abort();
                controller = new AbortController();

                const params = new URLSearchParams();
                params.set('search', searchInput.value);

                try {
                    const response = await fetch(
                        `{{ route('books.index') }}?${params.toString()}`,
                        {
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest',
                                'Accept': 'application/json'
                            },
                            signal: controller.signal
                        }
                    );

                    if (!response.ok) throw new Error('Search failed');

                    const data = await response.json();
                    results.innerHTML = data.html;
                    count.textContent = data.count;
                } catch (error) {
                    if (error.name !== 'AbortError') {
                        console.error(error);
                    }
                }
            });
        });
    </script>
</x-app-layout>
